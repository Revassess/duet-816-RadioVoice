create view acdc_songs
            ("TrackId", "Name", "AlbumId", "MediaTypeId", "GenreId", "Composer", "Milliseconds", "Bytes",
             "UnitPrice") as
SELECT "Track"."TrackId",
       "Track"."Name",
       "Track"."AlbumId",
       "Track"."MediaTypeId",
       "Track"."GenreId",
       "Track"."Composer",
       "Track"."Milliseconds",
       "Track"."Bytes",
       "Track"."UnitPrice"
FROM "Track"
WHERE ("Track"."AlbumId" IN (SELECT "Album"."AlbumId"
                             FROM "Album"
                             WHERE ("Album"."ArtistId" IN (SELECT "Artist"."ArtistId"
                                                           FROM "Artist"
                                                           WHERE "Artist"."Name"::text = 'AC/DC'::text))));

alter table acdc_songs
    owner to connellrobert;

